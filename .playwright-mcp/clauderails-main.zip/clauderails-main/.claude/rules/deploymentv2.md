# Deployment

> Target: Docker on Ubuntu Server. Every change must be deployment-ready for Linux containers.

## Architecture

```
Browser → Traefik (443) → Frontend (Next.js :3000) → [rewrites] → Backend (Go :3100) → PostgreSQL
```

- **Frontend**: Next.js (standalone mode) — the ONLY service exposed via Traefik
- **Backend**: Go (chi router) — internal only, NOT reachable from the internet
- **All browser API requests go through the frontend** via Next.js rewrites. The backend has no Traefik labels and lives only on the internal Docker network.

## Networks

- **frontnet**: connected to Traefik, internet-facing
- **backnet**: internal only, no internet access
- Frontend joins both networks. Backend and database join `backnet` only.

## Linux Compatibility (Critical — Dev Hosts Are Windows)

- **Line endings**: All files must use LF (`\n`), never CRLF. Configure `.gitattributes` accordingly.
- **File paths**: Always use forward slashes (`/`). Never use backslashes or Windows-only path APIs.
- **Case sensitivity**: Linux filesystems are case-sensitive. Imports must match exact file casing.
- **Shell scripts / entrypoints**: LF line endings, Unix syntax. No PowerShell, no `cmd`.
- **File permissions**: Respect Unix permissions in Dockerfiles.

## Next.js Standalone Mode (Critical)

- **`output: "standalone"`** must remain set in `next.config.ts`.
- **`NEXT_PUBLIC_*` vars are baked at build time.** They are NOT available at container runtime. Never set them in `docker-compose.yml` `environment:` — pass them as Dockerfile `ARG`/`ENV` before `npm run build`.
- **`next.config.ts` rewrites are evaluated at build time.** Rewrite destinations must use a variable available during build (e.g., `API_INTERNAL_URL` passed as Dockerfile `ARG`).
- **Standalone binds to container hostname by default.** Always set `HOSTNAME: "0.0.0.0"` in container environment so the frontend is reachable.

## API Call Rules

### Browser-Side

- Use same-origin (`""` or relative paths) as API base URL. Never use `localhost:3100` or any direct backend URL — the backend is not exposed.
- Next.js rewrites in `next.config.ts` proxy `/api/*` and `/auth/*` to the backend.
- Use `credentials: "include"` on all fetch calls (cookie-based auth).

### Server-Side (SSR)

- Use `process.env.API_INTERNAL_URL` (e.g., `http://3cxbackend:3100`).
- Fallback to `http://localhost:3100` for local development.

## CORS

- CORS on the backend is effectively unused in production — the browser never talks to the backend directly.
- Do not expose the backend externally to "fix" CORS issues. The correct fix is ensuring Next.js rewrites work.

## Docker Build Strategy

### Separate build script and compose 
- **Do not use `build:` in docker-compose.** Create a build script that builds images with incrementing version numbers.
- **Version Numbers** should follow the project version number and apply basic Version control standars 
- **Docker-compose references `latest` tag.**

### Frontend Dockerfile

- Accept `API_INTERNAL_URL` as build `ARG`, set as `ENV` before `npm run build`.
- Multi-stage build: build stage + lean runner copying only `.next/standalone`, `.next/static`, and `public`.
- Include `.dockerignore` excluding `node_modules`, `.next`, `.git`.

### Backend Dockerfile (Go)

- Multi-stage build: `golang` image for build, minimal image (e.g., `alpine`) for runtime.
- Compile for `linux/amd64` — never ship a Windows binary.

## Docker Compose Rules
### General Ruels
- Backend must NOT have Traefik labels. Must NOT be on `frontnet`.
- Frontend must be on both `frontnet` and `backnet`.
- Use project-prefixed service names (e.g., `3cx-backend`, not `backend`).
- Set `HOSTNAME: "0.0.0.0"` on frontend container.

### Predefined values
- In `networks` the network `frontnet` has to be defined with `name: frontnet` and `external: true`
- In `networks` the network `backnet` has to be defined with `name: backnet` and `external: true`
- The lable `traefik.enable=true` always has to exist
- The lable `traefik.http.routers.<#ServiceName#>.rule=Host(<#ServiceName.hikoservice.de#>)` always has to exist
- The lable `traefik.http.routers.<#ServiceName#>.tls=true` always has to exist
- The lable `traefik.http.routers.<#ServiceName#>.tls.certresolver=autodns` always has to exist
- The lable `traefik.http.routers.<#ServiceName#>.tls.domains[0].main=hikoservice.de` always has to exist
- The lable `traefik.http.routers.<#ServiceName#>.tls.domains[0].sans=*.hikoservice.de` always has to exist

## Pre-Deployment Checklist

1. `next.config.ts` rewrites use `API_INTERNAL_URL` (not `NEXT_PUBLIC_API_URL`).
2. Frontend Dockerfile passes `API_INTERNAL_URL` as build `ARG`.
3. Backend has NO Traefik labels, is on internal network only.
4. `HOSTNAME: "0.0.0.0"` set on frontend container.
5. All file paths are Unix-compatible (forward slashes, correct casing).
6. `.dockerignore` files exist for frontend and backend.
7. No `NEXT_PUBLIC_*` vars relied upon at runtime.

## Key Files

- `docker-compose.yaml` — service definitions, networks
- `frontend/Dockerfile` — must pass `API_INTERNAL_URL` as build ARG
- `frontend/next.config.ts` — rewrites proxying API/auth routes to backend
- `frontend/src/lib/api.ts` — browser uses same-origin, server uses `API_INTERNAL_URL`
- `backend/cmd/api/main.go` — Go server entry point
- `backend/internal/config/config.go` — backend configuration
- `.env` — Enviroment variables

## Local Development

Frontend dev server (`npm run dev`) reaches the backend at `http://localhost:3100` via rewrites fallback. No CORS issues since rewrites act as a server-side proxy.
